JINNY STARTER — FREE PROTOTYPE

Included:
- index.html: app interface and basic reply logic
- manifest.json: installable PWA metadata
- icon.svg: app icon
- sw.js: service worker/offline cache

Important limitations:
- This is a starter prototype, not a full Jarvis or a connected large-language-model assistant.
- Voice input depends on browser support, microphone permission, and internet/browser speech service.
- Voice output uses the browser's speech synthesis.
- Reliable background reminders, automatic phone control, always-listening activation, private account integrations, and advanced AI require additional setup and permissions.
- No API keys or paid services are included.

To make it installable:
1. Upload all four app files (index.html, manifest.json, icon.svg, sw.js) to a static HTTPS host such as GitHub Pages.
2. Open the published HTTPS URL in Chrome on Android.
3. Chrome menu (three dots) > Add to Home screen / Install app.

Do not upload passwords, OTPs, or private financial information into a public repository.
